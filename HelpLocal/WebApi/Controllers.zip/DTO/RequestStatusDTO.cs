﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApi.DTO
{
    public class RequestStatusDTO
    {
        public string StudentId { get; set; }
        public string RequestStatus { get; set; }
    }
}